﻿using BaseInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modBL.prime.tienluong
{
    public class colU : ACell
    {
        public colU(Option opt) : base(opt)
        {
        }

        // Cột U cho row object
        public override string CName => "U";
        public override string UName => "CongViec_ThanhTienMay";

        /// <summary>
        /// chỉ có 1 phần từ
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public override string formula(string[] args)
        {
            return $"=M{args[0]}*Q{args[0]}";
        }
    }
}
