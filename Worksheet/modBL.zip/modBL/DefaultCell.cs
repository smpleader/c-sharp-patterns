﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Worksheet.modBL
{
    internal class DefaultCell : ICell
    {
        public string option { get { return ""; } }

        public string Col => "A";

        public string Name => throw new NotImplementedException();

        // return forumalation of cell
        public string fml()
        {
            return "";
        }
        // return value of cell
        public decimal val()
        {
            return 0;
        }

        string ICell.formula(string[] args)
        {
            throw new NotImplementedException();
        }
    }
}
