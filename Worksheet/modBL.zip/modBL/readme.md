﻿- Folder name == sheet name
- Class name == cell
- 